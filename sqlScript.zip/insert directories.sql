insert into [engine] (engine) values('Бензиновый');
insert into [engine] (engine) values('Дизельный');
insert into [engine] (engine) values('Газовый');
insert into [engine] (engine) values('Электрический');
insert into [engine] (engine) values('Гибридный');

insert into [transmission] (transmission) values('Механическая');
insert into [transmission] (transmission) values('Автоматическая');
insert into [transmission] (transmission) values('Роботизированная');
insert into [transmission] (transmission) values('Вариативная');

insert into [carcase] (carcase) values('Седан');
insert into [carcase] (carcase) values('Купе');
insert into [carcase] (carcase) values('Хэтчбек');
insert into [carcase] (carcase) values('Лифтбек');
insert into [carcase] (carcase) values('Фастбэк');
insert into [carcase] (carcase) values('Универсал');
insert into [carcase] (carcase) values('Кроссовер');
insert into [carcase] (carcase) values('Внедорожник');
insert into [carcase] (carcase) values('Пикап');
insert into [carcase] (carcase) values('Легковой фургон');
insert into [carcase] (carcase) values('Минивэн');
insert into [carcase] (carcase) values('Компактвэн');
insert into [carcase] (carcase) values('Микровэн');
insert into [carcase] (carcase) values('Кабриолет');
insert into [carcase] (carcase) values('Родстер');
insert into [carcase] (carcase) values('Тарга');
insert into [carcase] (carcase) values('Ландо');
insert into [carcase] (carcase) values('Лимузин');

insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Сергей','Катаев','Валентинович',4,'универсал',250);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Иван','Сидин','Анатольевич',4,'универсал',250);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Владимир','Маслов','Андреевич',6,'универсал',350);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Евгений','Гудин','Гудинич',5,'универсал',300);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Евгений','Гудин','Вадимович',4,'универсал',250);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Евгений','Гудин','Артурович',3,'кузовной ремонт',200);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Евгений','Годок','Андронович',6,'двигатели',450);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Арсений','Годок','Витальевич',6,'электроника',500);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Иван','Годок','Адольфович',4,'шиномонтаж',200);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Виктор','Рыбин','Иванович',1,'приемщик',150);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Игорь','Торгуев','Павлович',1,'приемщик',151);
insert into [Employees] (Name, Surname, Midname, Category, specialization,salary) values ('Малева','Андреевна','Ирина',1,'кассир',200);

insert into [steps] (name) values('приемка');
insert into [steps] (name) values('ожидание');
insert into [steps] (name) values('согласование');
insert into [steps] (name) values('мойка');
insert into [steps] (name) values('диагностика 1');
insert into [steps] (name) values('диагностика 2');
insert into [steps] (name) values('стенд развал-схождение');
insert into [steps] (name) values('смотровая');
insert into [steps] (name) values('стоянка');
insert into [steps] (name) values('ТО');
insert into [steps] (name) values('контроль');
insert into [steps] (name) values('пункт замены масла');

insert into [works] (name, price, category, duration) values('экспресс-мойка',300,1,20);
insert into [works] (name, price, category, duration) values('компьютерная диагностика',3500,4,60);
insert into [works] (name, price, category, duration) values('регулировка развал-схождение',1500,3,40);
insert into [works] (name, price, category, duration) values('замена моторного масла',1000,2,120);
insert into [works] (name, price, category, duration) values('шиномонтаж',500,1,15);
insert into [works] (name, price, category, duration) values('замена воздушного фильтра',750,3,20);
insert into [works] (name, price, category, duration) values('покраска элемента',8000,4,400);
insert into [works] (name, price, category, duration) values('замена сигнализации',5500,4,60);
insert into [works] (name, price, category, duration) values('замена тормозных колодок',2000,3,40);

insert into [typepay] (type) values('наличные');
insert into [typepay] (type) values('безналичная');
insert into [typepay] (type) values('перевод СБП');
insert into [typepay] (type) values('по реквизитам счет');

insert into [status] (status) values('наличие');
insert into [status] (status) values('в работе');
insert into [status] (status) values('заказано');
insert into [status] (status) values('в пути');
insert into [status] (status) values('установлено');
insert into [status] (status) values('к списанию');
insert into [status] (status) values('ожидание');

