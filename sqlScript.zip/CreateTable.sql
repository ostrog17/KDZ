CREATE TYPE id FROM NUMERIC NOT NULL;
CREATE TYPE name FROM CHAR(30) NULL;

go

CREATE TABLE Clients
( 
	IdClient             id PRIMARY KEY IDENTITY(1,1) ,
	Name                 name ,
	Surname              name ,
	Midname              name,
	Birthday             datetime  NULL ,
	Address              name ,
	Phone                name ,
	Male                 bit,
	Regular              bit NULL default 0
);

CREATE TABLE Carcase
( 
	IdCarcase            id  PRIMARY KEY  NOT NULL Identity(1,1),
	Carcase              name 
);

CREATE TABLE Engine
( 
	IdEngine             id  NOT NULL PRIMARY KEY IDENTITY(1,1),
	Engine               name 
);

CREATE TABLE Transmission
( 
	IdTransmission       id  PRIMARY KEY  NOT NULL Identity(1,1),
	Transmission         name 
);

go

CREATE TABLE [Cars]
( 
	IdCar                id NOT NULL PRIMARY KEY IDENTITY(1,1) ,
	Brand                name ,
	Model               name ,
	Release              varchar(4) check (Release>1900 and  Release<(year(getdate()))),
	EngCapacity		 name,
	CarNum               name ,
	VIN 				varchar(17),
	Engine			numeric,
	IdClient			numeric,
	Carcase			numeric,
	Transmission		numeric,
	FOREIGN KEY (Engine) REFERENCES Engine(IdEngine)
		ON DELETE NO ACTION
		ON UPDATE CASCADE,
	FOREIGN KEY (IdClient)    REFERENCES [Clients](IdClient)
		ON DELETE NO ACTION
		ON UPDATE CASCADE,
	 FOREIGN KEY (Carcase)	 REFERENCES [Carcase](IdCarcase)
		ON DELETE NO ACTION
		ON UPDATE CASCADE,
	FOREIGN KEY (Transmission)	REFERENCES [Transmission](IdTransmission)
		ON DELETE NO ACTION
		ON UPDATE CASCADE	
);

CREATE TABLE Works
( 
	IdWork               id  PRIMARY KEY IDENTITY(1,1),
	Name                 name ,
	Price                money  NULL ,
	Category             integer  NULL ,
	Duration             integer  NULL 
);

CREATE TABLE Status
(
	IdStatus id PRIMARY KEY IDENTITY(1,1) NOT NULL,
	Status name NULL
);

go

CREATE TABLE Stock
( 
	IdStock              char(18)  NOT NULL ,
	Name                 name ,
	Maker                name ,
	Count                integer  NULL ,
	Status               numeric ,
	Price                money  NULL,
 	FOREIGN KEY (Status) REFERENCES [Status](IdStatus)
		ON DELETE NO ACTION
		ON UPDATE CASCADE
);

CREATE TABLE Employees
( 
	IdEmpl              id primary key identity(1,1),
	Name                 name ,
	Midname	   	     name,
	Surname              name ,
	Category             name ,
	Specialization       name ,
	Salary               money  NULL
);

CREATE TABLE Steps
( 
	IdStep              id primary key identity(1,1),
	Name                 name 
);

go
CREATE TABLE [Order]
( 
	IdOrder               id primary key identity(1,1) ,
	ODate                 datetime  NULL ,
	Acceptor              id ,
	IdCar                 id ,
	Mechanic              numeric  NULL ,
	Mileage               integer  NULL ,
	Defect                name ,
	Comment               varchar(200)  NULL ,
	StartTime             datetime  NULL ,
	EndTime               datetime  NULL ,
	CurrentStep           numeric  NULL ,
	NextStep              numeric  NULL ,
	FOREIGN KEY (IdCar) REFERENCES Cars(IdCar)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	FOREIGN KEY (Mechanic) REFERENCES Employees (IdEmpl)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	FOREIGN KEY (Acceptor) REFERENCES Employees (IdEmpl)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	FOREIGN KEY (CurrentStep) REFERENCES Steps (IdStep)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	FOREIGN KEY (NextStep) REFERENCES Steps (IdStep)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
);

go

CREATE TABLE WOrderSpecification
( 
	IdSpec               id primary key identity(1,1) ,
	IdOrder              id ,
	IdWork               id,
	count	  	integer,
	FOREIGN KEY (IdWork) REFERENCES [Works](IdWork)
		ON DELETE NO ACTION
		ON UPDATE CASCADE,
	FOREIGN KEY (IdOrder) REFERENCES [Order](IdOrder)
		ON DELETE CASCADE
		ON UPDATE CASCADE
);

CREATE TABLE [SOrderSpecification]
( 
	IdSpec               id primary key identity(1,1) ,
	IdOrder              id ,
	IdStock              id NOT NULL,
	Count                integer  default 1,
	FOREIGN KEY (IdOrder) REFERENCES [Order](IdOrder)
		ON DELETE CASCADE
		ON UPDATE CASCADE,
	FOREIGN KEY (IdStock) REFERENCES [Stock](IdS)
		ON DELETE NO ACTION
		ON UPDATE CASCADE
);

CREATE TABLE TypePay
( 
	IdType              id primary key identity(1,1),
	Type                 name 
);

go

CREATE TABLE Payment
( 
	IdPay              id primary key identity(1,1),
	[Order]              id,
	PayDate			date,
	[Type]				numeric,
	cashier				numeric,
	sum					money,
	FOREIGN KEY ([Order]) REFERENCES [Order](IdOrder)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	FOREIGN KEY ([Type]) REFERENCES [TypePay](IdType)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	FOREIGN KEY (Cashier) REFERENCES [Employees](IdEmpl)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
);

go


